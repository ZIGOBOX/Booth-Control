BOOTH CONTROL - projet Android

Fonctions :
- Connexion directe au PC sur le réseau local
- Port dslrBooth configurable (1500 par défaut)
- Mot de passe API mémorisé sur le téléphone
- Déclenchement photo
- Impression de la dernière photo en 1, 2 ou 3 copies
- Annulation de session
- Aucun logiciel additionnel à installer sur le PC

Endpoints utilisés :
/api/start?mode=print
/api/print?count=1 (ou 2 / 3)
/api/cancel
Le mot de passe est ajouté comme paramètre ?password=...
