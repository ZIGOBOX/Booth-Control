package fr.zigobox.boothcontrol;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private EditText ipField;
    private EditText portField;
    private EditText passwordField;
    private TextView status;
    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("booth_control", MODE_PRIVATE);
        buildUi();
        loadSettings();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("BOOTH CONTROL");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Télécommande locale dslrBooth");
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(4), 0, dp(18));
        root.addView(subtitle, matchWrap());

        ipField = addField(root, "Adresse IP du PC (ex. 192.168.137.1)", InputType.TYPE_CLASS_PHONE);
        portField = addField(root, "Port API (1500)", InputType.TYPE_CLASS_NUMBER);
        passwordField = addField(root, "Mot de passe API dslrBooth", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        Button save = addButton(root, "ENREGISTRER", 54);
        save.setOnClickListener(v -> {
            saveSettings();
            toast("Réglages enregistrés");
        });

        Button test = addButton(root, "TESTER LA CONNEXION", 54);
        test.setOnClickListener(v -> testConnection());

        status = new TextView(this);
        status.setText("Prêt");
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(12), 0, dp(12));
        root.addView(status, matchWrap());

        Button photo = addButton(root, "📸  PRENDRE UNE PHOTO", 72);
        photo.setTextSize(20);
        photo.setOnClickListener(v -> sendCommand("/api/start?mode=print", "Déclenchement photo"));

        LinearLayout prints = new LinearLayout(this);
        prints.setOrientation(LinearLayout.HORIZONTAL);
        prints.setGravity(Gravity.CENTER);
        root.addView(prints, matchWrap());

        Button p1 = addSmallButton(prints, "🖨 1");
        Button p2 = addSmallButton(prints, "🖨 2");
        Button p3 = addSmallButton(prints, "🖨 3");
        p1.setOnClickListener(v -> sendCommand("/api/print?count=1", "Impression 1 copie"));
        p2.setOnClickListener(v -> sendCommand("/api/print?count=2", "Impression 2 copies"));
        p3.setOnClickListener(v -> sendCommand("/api/print?count=3", "Impression 3 copies"));

        Button cancel = addButton(root, "✖  ANNULER", 62);
        cancel.setOnClickListener(v -> sendCommand("/api/cancel", "Annulation"));

        TextView note = new TextView(this);
        note.setText("Le téléphone et le PC doivent être sur le même réseau local. Rien d'autre n'est installé sur le PC : dslrBooth doit simplement avoir son API activée.");
        note.setTextSize(13);
        note.setPadding(0, dp(20), 0, 0);
        root.addView(note, matchWrap());

        setContentView(scroll);
    }

    private EditText addField(LinearLayout root, String hint, int inputType) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setInputType(inputType);
        field.setSingleLine(true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(5), 0, dp(5));
        root.addView(field, lp);
        return field;
    }

    private Button addButton(LinearLayout root, String text, int heightDp) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(heightDp));
        lp.setMargins(0, dp(6), 0, dp(6));
        root.addView(b, lp);
        return b;
    }

    private Button addSmallButton(LinearLayout row, String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(18);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(68), 1f);
        lp.setMargins(dp(3), dp(4), dp(3), dp(4));
        row.addView(b, lp);
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private void loadSettings() {
        ipField.setText(prefs.getString("ip", "192.168.137.1"));
        portField.setText(prefs.getString("port", "1500"));
        passwordField.setText(prefs.getString("password", ""));
    }

    private void saveSettings() {
        prefs.edit()
                .putString("ip", ipField.getText().toString().trim())
                .putString("port", portField.getText().toString().trim())
                .putString("password", passwordField.getText().toString())
                .apply();
    }

    private boolean validateSettings() {
        String ip = ipField.getText().toString().trim();
        String port = portField.getText().toString().trim();
        if (ip.isEmpty() || port.isEmpty()) {
            toast("Renseigne l'adresse IP et le port");
            return false;
        }
        saveSettings();
        return true;
    }

    private void testConnection() {
        if (!validateSettings()) return;
        setStatus("Test de connexion…");
        String ip = ipField.getText().toString().trim();
        int port;
        try {
            port = Integer.parseInt(portField.getText().toString().trim());
        } catch (Exception e) {
            toast("Port incorrect");
            return;
        }
        executor.execute(() -> {
            try (Socket socket = new Socket()) {
                socket.connect(new InetSocketAddress(ip, port), 2500);
                runOnUiThread(() -> setStatus("✅ PC joignable sur le port " + port));
            } catch (Exception e) {
                runOnUiThread(() -> setStatus("❌ Connexion impossible : " + shortError(e)));
            }
        });
    }

    private void sendCommand(String pathAndQuery, String label) {
        if (!validateSettings()) return;
        String ip = ipField.getText().toString().trim();
        String port = portField.getText().toString().trim();
        String password = passwordField.getText().toString();
        String separator = pathAndQuery.contains("?") ? "&" : "?";
        String encodedPassword = URLEncoder.encode(password, StandardCharsets.UTF_8);
        String url = "http://" + ip + ":" + port + pathAndQuery + separator + "password=" + encodedPassword;

        setStatus(label + "…");
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new java.net.URL(url).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(3000);
                connection.setReadTimeout(5000);
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 400 ? connection.getInputStream() : connection.getErrorStream();
                String body = readShort(stream);
                final String msg = (code >= 200 && code < 300 ? "✅ " : "⚠️ ") + label + " — HTTP " + code + (body.isEmpty() ? "" : " — " + body);
                runOnUiThread(() -> setStatus(msg));
            } catch (Exception e) {
                runOnUiThread(() -> setStatus("❌ " + label + " : " + shortError(e)));
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private String readShort(InputStream in) {
        if (in == null) return "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
            String line = br.readLine();
            if (line == null) return "";
            return line.length() > 120 ? line.substring(0, 120) : line;
        } catch (Exception ignored) {
            return "";
        }
    }

    private String shortError(Exception e) {
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? e.getClass().getSimpleName() : m;
    }

    private void setStatus(String text) {
        status.setText(text);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
